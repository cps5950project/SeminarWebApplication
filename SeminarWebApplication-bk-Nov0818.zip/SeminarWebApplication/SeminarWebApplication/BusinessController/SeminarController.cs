﻿using BusinessController;
using DbAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SeminarWebApplication.BusinessController
{
    public class SeminarController
    {

        public void GetDeptAll(ref DataTable tbl)
        {
            string query = "";
            tbl.Rows.Clear();
            query = "exec GetDeptAll";
            Db.selectDataReader(ref tbl, query);

        }
        public void GetSeminarForEdit(ref DataTable tbl, string seminar_id)
        {
            string StoredProcedure = "GetSeminarForEdit";
            /*Below code will Protect From SQL Injection in ASP.NET*/
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@seminar_id", SqlDbType.VarChar, 25) { Value = seminar_id }
                  
                };
            Db.selectDataReader(ref tbl, StoredProcedure, Parameters);
        }
        public void DeleteSeminar(string seminar_id)
        { 
            /*Below code will Protect From SQL Injection in ASP.NET*/
            string StoredProcedureName = "DeleteSeminar";
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@seminar_id", SqlDbType.VarChar, 18) { Value = seminar_id }
                

                };
            Db.executeQuery(StoredProcedureName, Parameters);
        }

        public void CencelEnrollment(string enroll_id) 
        {
            /*Below code will Protect From SQL Injection in ASP.NET*/
            string StoredProcedureName = "CencelEnrollment";
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@enroll_id", SqlDbType.VarChar, 18) { Value = enroll_id }
                

                };
            Db.executeQuery(StoredProcedureName, Parameters);
        }
        public void GetTermAll(ref DataTable tbl)
        {
            string query = "";
            tbl.Rows.Clear();
            query = "exec GetTermAll";
            Db.selectDataReader(ref tbl, query);

        }


        public void GetSeminarAll(ref DataTable tbl)
        { 
            string query = "";
            tbl.Rows.Clear();
            query = "exec GetSeminarAll";
            Db.selectDataReader(ref tbl, query);

        }

        public void GetSeminarAll_byCat(ref DataTable tbl)
        { 
            string query = "";
            tbl.Rows.Clear();
            query = "exec GetSeminarByCat";
            Db.selectDataReader(ref tbl, query);

        }

        public void GetSeminar_EnrollAll(ref DataTable tbl, string UserID)
        {
            string StoredProcedure = "";
            tbl.Rows.Clear();
            StoredProcedure = "GetSeminar_EnrollAll";
            

            /*Below code will Protect From SQL Injection in ASP.NET*/
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@UserID", SqlDbType.BigInt, 18) { Value = UserID }
                  
                };
            Db.selectDataReader(ref tbl, StoredProcedure, Parameters);

        } 

        public void GetSeminar_EnrollByCriteria(ref DataTable tbl, string UserID ,string TermID,string department_id)
        {
            string StoredProcedure = "";
            tbl.Rows.Clear();
            StoredProcedure = "GetSeminar_EnrollByCriteria";


            /*Below code will Protect From SQL Injection in ASP.NET*/
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@UserID", SqlDbType.BigInt, 18) { Value = UserID },
                  new SqlParameter("@TermID", SqlDbType.BigInt, 18) { Value = TermID },
                  new SqlParameter("@department_id", SqlDbType.BigInt, 18) { Value = department_id }
                  
                };
            Db.selectDataReader(ref tbl, StoredProcedure, Parameters);

        }

        //

        public void SaveSeminar(string seminar_id, string seminar_title, string organizar_name,
     string place, string Seminartime, string seminar_date, string department_id,string TermID,
    bool active
   )
        {
            

            seminar_id = commonController.removeSingleChar(seminar_id);
            seminar_title = commonController.removeSingleChar(seminar_title);

            organizar_name = commonController.removeSingleChar(organizar_name);
            place = commonController.removeSingleChar(place);
            Seminartime = commonController.removeSingleChar(Seminartime);
            seminar_date = commonController.removeSingleChar(seminar_date);


            string StoredProcedureName = "SaveSeminar";
            /*Below code will Protect From SQL Injection in ASP.NET*/
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@seminar_id", SqlDbType.VarChar, 18) { Value = seminar_id },
                  new SqlParameter("@seminar_title", SqlDbType.VarChar, 300) { Value = seminar_title },
                  new SqlParameter("@organizar_name", SqlDbType.VarChar, 200) { Value = organizar_name },
                 

                  new SqlParameter("@place", SqlDbType.VarChar, 50) { Value = place },
                  new SqlParameter("@Seminartime", SqlDbType.VarChar, 50) { Value = Seminartime },
                  new SqlParameter("@seminar_date", SqlDbType.VarChar, 20) { Value = seminar_date },
                  new SqlParameter("@department_id", SqlDbType.VarChar, 18) { Value = department_id },
                    new SqlParameter("@TermID", SqlDbType.VarChar, 18) { Value = TermID },
                  

                  new SqlParameter("@active", SqlDbType.Bit, 18) { Value = active }
                 

                };
            Db.executeQuery(StoredProcedureName, Parameters);


        }




        public void SaveSeminar_Enrollment(string enroll_id, string seminar_id, string UserID

)
        {




            string StoredProcedureName = "SaveSeminar_Enrollment";
            /*Below code will Protect From SQL Injection in ASP.NET*/
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@enroll_id", SqlDbType.VarChar, 18) { Value = enroll_id },
                  new SqlParameter("@seminar_id", SqlDbType.VarChar, 18) { Value = seminar_id },
                  new SqlParameter("@UserID", SqlDbType.VarChar, 18) { Value = UserID }
                 

                };
            Db.executeQuery(StoredProcedureName, Parameters);


        }




    }
}