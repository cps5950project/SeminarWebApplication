﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DbAccess;
using System.Web;
namespace BusinessController
{
    public class commonController
    {

        /* role_id	    role_name
         * -----------------------------------
             1	   -     student
             2	   -     admin	            
             3     -     organizer
         * ----------------------------------
         */



        
        public static String removeSingleChar(String str)
        { /*Prevent from attacks. Replacing single quote to double quote.*/
            str = str.Replace("'", "''");
            return str;
        }

        
        public void GetRoles(ref DataTable tbl)
        {
            string query = "";
            tbl.Rows.Clear();
            query = "exec sp_spGetRoles";
            Db.selectDataReader(ref tbl, query);

        }

        public Boolean SetRolesForPage(string pagename_needforAccess)
        {
            if (HttpContext.Current.Session["LoggedInUserRoleID"].ToString().Trim().ToLower() == "2")
            {
                /*All Pages are accessible for admin*/
            
                return true;
            }
            else if (HttpContext.Current.Session["LoggedInUserRoleID"].ToString().Trim().ToLower() == "3")
            {//organizer
                
                
                if (pagename_needforAccess=="seminar"
                || pagename_needforAccess=="search-seminar"
                || pagename_needforAccess=="Default"
             
                

               )
                { /*These pages are accessible*/
                    return true;
                }

            }
            else if (HttpContext.Current.Session["LoggedInUserRoleID"].ToString().Trim().ToLower() == "1")
            {//student
                /*Only These pages are accessible for this user*/
                if (pagename_needforAccess=="enroll-seminar-search"
                    || pagename_needforAccess=="enroll-seminar"
                    || pagename_needforAccess=="Default"
                    
                   )
                {
                    return true;
                }
                else
                    return false;


            }


       



     
     
            return false;
        }




    }
}
