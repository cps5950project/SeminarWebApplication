﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DbAccess;
using System.Data.OleDb;
using System.Data.SqlClient;
namespace BusinessController
{

    public class departmentController
    {

        public void GetAllDepartment(ref DataTable tbl)
        {
            string query = "";
            tbl.Rows.Clear();
            query = "exec sp_spGetAllDep";             
            Db.selectDataReader(ref tbl, query);


        }

        public void GetDeptForGrid(ref DataTable tbl)
        { 
            string query = "";
            tbl.Rows.Clear();
            query = "exec sp_spGetDeptDataForGrid";
            Db.selectDataReader(ref tbl, query);


        }

        public void GetDeptForGrid(ref DataTable tbl, string department_name, string PageSize, string PageNumber)
        {
            department_name = commonController.removeSingleChar(department_name);
           
            string StoredProcedureName = "SearchGetDeptDataForGrid";            
            /*Below code will Protect From SQL Injection in ASP.NET*/
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@department_name", SqlDbType.VarChar, 150) { Value = department_name },
                  new SqlParameter("@PageSize", SqlDbType.VarChar, 3) { Value = PageSize },
                   new SqlParameter("@PageNumber", SqlDbType.VarChar, 3) { Value = PageNumber }

                };
            Db.selectDataReader(ref tbl, StoredProcedureName, Parameters);


        }
        public void CheckDuplicatImport(ref DataTable tbl, string Import_fileName) 
        {
            string query = "";
            Import_fileName = commonController.removeSingleChar(Import_fileName);
            tbl.Rows.Clear();
            query = "exec [sp_spCheckDuplicatDepartMentFiles] '" + Import_fileName + "'";
            Db.selectDataReader(ref tbl, query);

        }
        public void BulkImport(OleDbDataReader dReader, string asset_Id, string created_by, string created_by_user_id, string Import_fileName)
        {
            

            /*=======================Bulk insertion with transaction======================================*/
            String queryToDelTempTable = "delete from DeparmentBulkImport";
            /*insert  into asset table*/
            created_by = commonController.removeSingleChar(created_by);
            Import_fileName = commonController.removeSingleChar(Import_fileName);
            String queryToExeProcedure = "";
            queryToExeProcedure = "exec [sp_spDepartmentBulkInsert] " + asset_Id
                 + ", '" + created_by + "'"
                 + ", '" + created_by_user_id + "'"
                 + ", '" + Import_fileName + "'";

            Db.BulkInsertTransaction(queryToDelTempTable, dReader, "DeparmentBulkImport", queryToExeProcedure);



        }
         
        public void BulkImportWithDataTable(DataTable  tbl, string asset_Id, string created_by, string created_by_user_id, string Import_fileName)
        {
             

            /*=======================Bulk insertion with transaction======================================*/
            String queryToDelTempTable = "delete from DeparmentBulkImport";
            /*insert  into asset table*/
            created_by = commonController.removeSingleChar(created_by);
            Import_fileName = commonController.removeSingleChar(Import_fileName);
            String queryToExeProcedure = "";
            queryToExeProcedure = "exec [sp_spDepartmentBulkInsert] " + asset_Id
                 + ", '" + created_by + "'"
                 + ", '" + created_by_user_id + "'"
                 + ", '" + Import_fileName + "'";

            Db.BulkInsertTransactionWithDataTable(queryToDelTempTable, tbl, "DeparmentBulkImport", queryToExeProcedure);



        }
        public void checkDeptExistInAsset(string department_id,ref DataTable tbl)
        {

            /*Below code will Protect From SQL Injection in ASP.NET*/
            string StoredProcedureName = "sp_spCheckDepartmentExist";
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@department_id", SqlDbType.VarChar, 18) { Value = department_id }
                };
            Db.selectDataReader(ref tbl, StoredProcedureName, Parameters);
        }
        public void DeleteDept(string department_id, string updated_by, string updated_by_user_id)
        {
             
            updated_by = commonController.removeSingleChar(updated_by);
         
            /*Below code will Protect From SQL Injection in ASP.NET*/
            string StoredProcedureName = "sp_spDeleteDepartment";
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@department_id", SqlDbType.VarChar, 18) { Value = department_id },
                    new SqlParameter("@updated_by", SqlDbType.VarChar, 50) { Value = updated_by },
                    new SqlParameter("@updated_by_user_id", SqlDbType.VarChar, 18) { Value = updated_by_user_id }

                };
            Db.executeQuery(StoredProcedureName, Parameters);
        }

        public void GetDeptForEdit(ref DataTable tbl, string department_id)
        { 
           

            /*Below code will Protect From SQL Injection in ASP.NET*/
            string StoredProcedureName = "sp_spGetDeptForEdit";
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@department_id", SqlDbType.VarChar, 18) { Value = department_id }
                   
                };
            Db.selectDataReader(ref tbl, StoredProcedureName, Parameters);
           
        }


        public void SaveDepartment(Int32 department_id, string department_name, string department_Code,
            string created_by, string campus_id,
            string campus_display_id,
                string  created_by_user_id,
               string updated_by_user_id,
            string ais_code
)
        {

            department_name = commonController.removeSingleChar(department_name);
            department_Code = commonController.removeSingleChar(department_Code);
            created_by = commonController.removeSingleChar(created_by);
            ais_code = commonController.removeSingleChar(ais_code);

            /*Below code will Protect From SQL Injection in ASP.NET*/
            string StoredProcedureName = "sp_spSaveDepartment";
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@department_id", SqlDbType.VarChar, 18) { Value = department_id },
                  new SqlParameter("@department_name", SqlDbType.VarChar, 150) { Value = department_name },
                  new SqlParameter("@department_Code", SqlDbType.VarChar, 150) { Value = department_Code },
                  new SqlParameter("@created_by", SqlDbType.VarChar, 50) { Value = created_by },
                  new SqlParameter("@campus_id", SqlDbType.VarChar, 18) { Value = campus_id },
                  new SqlParameter("@campus_display_id", SqlDbType.VarChar, 18) { Value = campus_display_id },
                  new SqlParameter("@created_by_user_id", SqlDbType.VarChar, 18) { Value = created_by_user_id },
                  new SqlParameter("@updated_by_user_id", SqlDbType.VarChar, 18) { Value = updated_by_user_id },
                  new SqlParameter("@ais_code", SqlDbType.VarChar, 150) { Value = ais_code },


                };
            Db.executeQuery(StoredProcedureName, Parameters);

        }

        /*-------Import Purpose------------------------------------------------------------*/
        public void SaveDepartment_Import(Int32 department_id, string department_name, string department_Code,
                string created_by, string campus_id,
                string campus_display_id,
                string created_by_user_id,                
                string ais_code
)
        {

            department_name = commonController.removeSingleChar(department_name);
            department_Code = commonController.removeSingleChar(department_Code);
            created_by = commonController.removeSingleChar(created_by);
            ais_code = commonController.removeSingleChar(ais_code);

            string query = "";
            query = "exec [sp_spSaveDepartment_Import] " + department_id
                + ", '" + department_name + "'"
                + ", '" + department_Code + "'"
                + ", '" + created_by + "'"
                + ", '" + campus_id + "'"
                + ", '" + campus_display_id + "'"
                + ", '" + created_by_user_id + "'"               
                + ", '" + ais_code + "'"
                 ;
            Db.executeQuery(query);

        }

        public void GetAllDeptID_Import(ref DataTable tbl)
        { 
            string query = "";
            tbl.Rows.Clear();
            query = "exec [sp_spGetAllDept_Import]";
            Db.selectDataReader(ref tbl, query);

        }

         
        public void InsertDept_ImporFileName(string Import_fileName)
        {

            Import_fileName = commonController.removeSingleChar(Import_fileName);
            string query = "";
            query = "exec [sp_spDeptImportFileInsert] '" + Import_fileName + "'";
            Db.executeQuery(query);

        }



    }
}
