﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DbAccess;
using System.Data.SqlClient;
namespace BusinessController
{
    public class userController
    {
        public void GetUserdata(ref DataTable tbl)
        {
            string query = "";
            tbl.Rows.Clear();
            query = "exec sp_spGetUserData";
            Db.selectDataReader(ref tbl, query);

        }

        public void GetUserForGrid(ref DataTable tbl)
        {
            string query = "";
            tbl.Rows.Clear();
            query = "exec sp_spGetUserDataForGrid";
            Db.selectDataReader(ref tbl, query);

        }
        public void GetUserForEdit(ref DataTable tbl, string UserID)
        { 
            string StoredProcedure = "sp_spGetUserForEdit";
            /*Below code will Protect From SQL Injection in ASP.NET*/
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@UserID", SqlDbType.VarChar, 25) { Value = UserID }
                  
                };
            Db.selectDataReader(ref tbl, StoredProcedure, Parameters);
        }
        public void GetUserDepartment(ref DataTable tbl)
        {
            string query = "";
            tbl.Rows.Clear();
            query = "exec sp_spGetRoles";
            Db.selectDataReader(ref tbl, query);
        }

        public void ChangLoginInfo(string employee_id, string login_name, string Password, string updated_by )
        {
            login_name = commonController.removeSingleChar(login_name);
            Password = commonController.removeSingleChar(Password);
            updated_by = commonController.removeSingleChar(updated_by);
                        
            string StoredProcedureName = "sp_spUpdateLoginInfo";
            /*Below code will Protect From SQL Injection in ASP.NET*/
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@employee_id", SqlDbType.VarChar, 18) { Value = employee_id },
                  new SqlParameter("@login_name", SqlDbType.VarChar, 25) { Value = login_name },
                  new SqlParameter("@Password", SqlDbType.VarChar, 16) { Value = Password },
                  new SqlParameter("@updated_by", SqlDbType.VarChar, 50) { Value = updated_by }

                };
            Db.executeQuery(StoredProcedureName, Parameters);
        }

        public void Saveuser(string UserID, string first_name, string last_name,string UserEmail,
             string Phone, string login_name, string Password, string role_id,
            bool active
           )
        {

            first_name = commonController.removeSingleChar(first_name);
            last_name = commonController.removeSingleChar(last_name);
            UserEmail = commonController.removeSingleChar(UserEmail);
          
            Phone = commonController.removeSingleChar(Phone);
            login_name = commonController.removeSingleChar(login_name);
            Password = commonController.removeSingleChar(Password);
            login_name = commonController.removeSingleChar(login_name);

    
            string StoredProcedureName = "sp_spSaveUser"; 
            /*Below code will Protect From SQL Injection in ASP.NET*/
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@UserID", SqlDbType.VarChar, 18) { Value = UserID },
                  new SqlParameter("@first_name", SqlDbType.VarChar, 50) { Value = first_name },
                  new SqlParameter("@last_name", SqlDbType.VarChar, 50) { Value = last_name },
                   new SqlParameter("@UserEmail", SqlDbType.VarChar, 50) { Value = UserEmail },
                 

                  new SqlParameter("@Phone", SqlDbType.VarChar, 50) { Value = Phone },
                  new SqlParameter("@login_name", SqlDbType.VarChar, 25) { Value = login_name },
                  new SqlParameter("@Password", SqlDbType.VarChar, 16) { Value = Password },
                  new SqlParameter("@role_id", SqlDbType.VarChar, 18) { Value = role_id },
                  

                  new SqlParameter("@active", SqlDbType.Bit, 18) { Value = active }
                 

                };
            Db.executeQuery(StoredProcedureName, Parameters);
            

        }


        public void GetUserLoginInfo(ref DataSet ds, string login_name, string Password)
        {


            login_name = commonController.removeSingleChar(login_name);
            Password = commonController.removeSingleChar(Password);
            string StoredProcedure = "sp_spGetLoginInfo";

            /*Below code will Protect From SQL Injection in ASP.NET*/
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@login_name", SqlDbType.VarChar, 25) { Value = login_name },
                  new SqlParameter("@Password", SqlDbType.VarChar, 16) { Value = Password }

                };
            Db.selectDataReader(ref ds, StoredProcedure, Parameters);


        }




        public void DeleteUser(string UserID)
        {
            /*Below code will Protect From SQL Injection in ASP.NET*/
            string StoredProcedureName = "sp_spDeleteUser"; 
            List<SqlParameter> Parameters = new List<SqlParameter>
                {   
                  new SqlParameter("@UserID", SqlDbType.VarChar, 18) { Value = UserID }
                

                };
            Db.executeQuery(StoredProcedureName, Parameters);
        }

    }
}
