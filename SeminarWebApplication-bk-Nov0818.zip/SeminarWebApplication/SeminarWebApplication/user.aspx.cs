﻿using BusinessController;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SeminarWebApplication
{
    public partial class user : System.Web.UI.Page
    {

        public string strDynamicMsg = "";
        commonController objCommonController = new commonController();

        public string requests_id
        {
            get
            {/*Prevent cross-site scripting*/
                if (!string.IsNullOrEmpty(Request.QueryString["requests_id"])) return Request.QueryString["requests_id"].ToString();
                else return "";
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {



            if (Session["LoggedIn"] == null)
            {
                Session["LoggedIn"] = false;
                Response.Redirect("signin.aspx");

            }
            pageLevelAcess();
            divmessage.Style["display"] = "none"; //hide            

            if (!IsPostBack)
            {
                if (Convert.ToBoolean(Session["LoggedIn"].ToString()) == false)
                {
                    Response.Redirect("signin.aspx");
                }

                fillcmbData();



                if (Request.QueryString["id"] != null)
                {
                    Session["id"] = Request.QueryString["id"].ToString().Trim();

                    fillUserDataForEdit(Session["id"].ToString());

                    if (Request.QueryString["requests_id"] != null)
                        strDynamicMsg = "Edit a user request";
                    else
                        strDynamicMsg = "Edit a user";

                }
                else
                {
                    strDynamicMsg = "Create a new user";
                }
            }

        }


        void pageLevelAcess()
        {
            string strcurrentPageName = Request.Url.AbsolutePath.ToString().Replace("/", "");
            /*Is Page is accessable for current user according to role*/
            if (objCommonController.SetRolesForPage(strcurrentPageName) == false)
            {
                Response.Redirect("default.aspx");
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            if (txtFirstName.Text.Trim() == string.Empty)
                return;
            if (txtEmail.Text.Trim() == string.Empty)
                return;
            string role_id = cmbRole.SelectedValue.ToString();
            bool active = false;


            active = chkActive.Checked;
            

            string UserID = "0"; 
            if (Session["id"] != null)
            {
                UserID = Session["id"].ToString();
            }

            userController objuserController = new userController();
            /*Below code will Protect From SQL Injection in ASP.NET*/
            objuserController.Saveuser(UserID,
                txtFirstName.Text.Trim(),
                txtlastname.Text.Trim(),
               txtEmail.Text.Trim(),
                txtPhone.Text.Trim(),
                txtloginname.Text.Trim(),
                txtPassword.Text.Trim(),
                role_id,
                active
               


                );



            divmessage.Style["display"] = "block"; //visible
            clear();

            if (UserID != "0")
            {/*Redirect after update*/
                Response.Redirect("user.aspx");
                // Request.QueryString["id"] = null; 
            }

        }

        void clear()
        {
            txtFirstName.Text = "";
            txtlastname.Text = "";
           
            txtPhone.Text = "";
            txtloginname.Text = "";
            txtPassword.Text = "";
            cmbRole.SelectedIndex = -1;
           
            chkActive.Checked = true;

            Session["id"] = null;

        }
        void fillUserDataForEdit(string UserID)
        {
            userController objuserController = new userController();
            DataTable tbl = new DataTable();
            objuserController.GetUserForEdit(ref tbl, UserID);

            DataRow[] drEdit = tbl.Select();
            if (drEdit.Length > 0)
            {


                txtFirstName.Text = drEdit[0]["first_name"].ToString().Trim();
                txtlastname.Text = drEdit[0]["last_name"].ToString().Trim();
                txtEmail.Text = drEdit[0]["UserEmail"].ToString().Trim();
                txtPhone.Text = drEdit[0]["phone"].ToString().Trim();
                txtloginname.Text = drEdit[0]["login_name"].ToString().Trim();
                txtPassword.Text = drEdit[0]["Password"].ToString().Trim();

                cmbRole.SelectedValue = drEdit[0]["role_id"].ToString().Trim();
               
               

                if (drEdit[0]["active"].ToString().Trim().ToLower() == "true")
                {
                    chkActive.Checked = true;
                }
                else
                {
                    chkActive.Checked = false;
                }



            }

        }
        void fillcmbData()
        {
            DataTable tblRoles = new DataTable();
            commonController objCommonController = new commonController();
            objCommonController.GetRoles(ref tblRoles);

            cmbRole.DataSource = tblRoles;
            cmbRole.DataTextField = "role_name";
            cmbRole.DataValueField = "role_id";
            cmbRole.DataBind();

           

        }


    }
}