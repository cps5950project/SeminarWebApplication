﻿using BusinessController;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SeminarWebApplication
{
    public partial class search_user : System.Web.UI.Page
    {
        commonController objCommonController = new commonController();

        public string htmldeleteHeaderCol = "";
        public string htmldeleteFooterCol = "";
        public int UserID
        {
            get
            {   /*Prevent cross-site scripting*/
                if (!string.IsNullOrEmpty(Request.QueryString["id"])) return Convert.ToInt32(Request.QueryString["id"]);
                else return 0;
            }
        } 
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["LoggedIn"] == null)
            {
                Session["LoggedIn"] = false;
                Response.Redirect("signin.aspx");

            }
            pageLevelAcess();
            if (!IsPostBack)
            {
                if (Convert.ToBoolean(Session["LoggedIn"].ToString()) == false)
                {
                    Response.Redirect("signin.aspx");
                }
                if (UserID != 0)
                {

                    deleteUser(UserID.ToString().Trim());

                }
                loadGrid();


            }

        }

        private void loadGrid()
        {
            userController objuserController = new userController();
            DataTable dt = new DataTable();
            objuserController.GetUserForGrid(ref dt);
            StringBuilder sb = new StringBuilder();

            if (dt != null)
                if (dt.Rows.Count > 0)
                    foreach (DataRow dr in dt.Rows)
                    {



                        sb.Append("<tr>");

                        sb.Append("<td>");
                        sb.Append(dr["first_name"].ToString().Trim());
                        sb.Append("</td>");

                        sb.Append("<td>");
                        sb.Append((dr["last_name"].ToString().Trim()));
                        sb.Append("</td>");

                        sb.Append("<td>");
                        sb.Append((dr["login_name"].ToString().Trim()));
                        sb.Append("</td>");

                        string activeDeactive = "";
                        string htmlActive = "<span class=\"label label-success\">Active</span>";
                        string htmlDeActive = "<span class=\"label label-info\">Deactive</span>";

                        if (dr["active"].ToString().Trim().ToLower() == "true")
                        {
                            activeDeactive = htmlActive;
                        }
                        else
                        {
                            activeDeactive = htmlDeActive;
                        }

                        sb.Append("<td>");
                        sb.Append((activeDeactive));
                        sb.Append("</td>");

                        string sendtopage = "user.aspx?id=" + dr["UserID"].ToString().Trim();
                        string lableName = "Edit";
                        string htmllink = "<a href=\"" + sendtopage + "\">" + lableName + "</a>";

                        sb.Append("<td>");
                        sb.Append((htmllink));
                        sb.Append("</td>");


                        htmldeleteHeaderCol = "<th tabindex=\"0\" rowspan=\"1\" colspan=\"1\">Delete</th>";
                        htmldeleteFooterCol = "<th rowspan=\"1\" colspan=\"1\">Delete</th>";
                        string lbldel = "";
                        string UserID = dr["UserID"].ToString().Trim();
                        sendtopage = "search-user.aspx?id=" + dr["UserID"].ToString().Trim();
                        lbldel = "Delete";
                        htmllink = "<a href=\"" + sendtopage + "\">" + lbldel + "</a>";
                        string strHmtlDe = htmllink;
                        sb.Append("<td>");
                        sb.Append((strHmtlDe));
                        sb.Append("</td>");

                        sb.Append("</tr>");

                    }

            ltData.Text = sb.ToString();



        }


        void pageLevelAcess()
        {
            string strcurrentPageName = Request.Url.AbsolutePath.ToString().Replace("/", "");
            /*Is Page is accessable for current user according to role*/
            if (objCommonController.SetRolesForPage(strcurrentPageName) == false)
            {
                Response.Redirect("default.aspx");
            }

        }

        void deleteUser(string UserID)
        {
            userController objuserController = new userController();
            /*Below code will Protect From SQL Injection in ASP.NET*/
            objuserController.DeleteUser(UserID );
            /*After Delete Redirect*/
            Response.Redirect("search-user.aspx");
        }




    }
}