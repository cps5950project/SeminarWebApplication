﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessController;
using System.Data;
namespace SeminarWebApplication
{
    public partial class signin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session["LoggedIn"] = false;
            }
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            if (Session["attempt"] == null)
            {

                Session["attempt"] = 1;
            }
            else
            {
                int i = int.Parse(Session["attempt"].ToString());

                Session["attempt"] = i + 1;
            }
            userController objuserController = new userController();
            if (!(String.IsNullOrEmpty(txtloginname.Text.Trim()))
                && !(String.IsNullOrEmpty(txtpass.Text.Trim()))) 
            {
                DataSet ds = new DataSet();
                DataTable tbluser = new DataTable();
                DataTable tblRoles = new DataTable();
                objuserController.GetUserLoginInfo(ref ds, txtloginname.Text.Trim(), txtpass.Text.Trim());
                tbluser = ds.Tables[0];
                tblRoles = ds.Tables[1];
                if (tbluser.Rows.Count > 0)
                {
                    Session["LoggedIn"] = true;
                    Session["LoggedInUserName"] = tbluser.Rows[0]["login_name"];
                    Session["UserName"] = tbluser.Rows[0]["last_name"] + ", " + tbluser.Rows[0]["first_name"];
                    Session["UserID"] = tbluser.Rows[0]["UserID"];
                    Session["UserEmail"] = tbluser.Rows[0]["UserEmail"];

                    DataRow[] drSelectRoles = tblRoles.Select("role_id='" + tbluser.Rows[0]["role_id"].ToString().Trim() + "'");
                    if (drSelectRoles.Length > 0)
                    {
                        Session["LoggedInUserRoleID"] = drSelectRoles[0]["role_id"].ToString().Trim();
                        Session["LoggedInUserRoleName"] = drSelectRoles[0]["role_name"].ToString().Trim();
                    }
                    else
                    {
                        Session["LoggedInUserRoleID"] = null;
                        Session["LoggedInUserRoleName"] = null;
                    }

                    Session["attempt"] = "0";
                    Response.Redirect("Default.aspx");

                   
                }
                else
                {
                    if (Session["attempt"].ToString() == "5")
                    {
                         lblmsg.Text = "Too many Attempts, Please Contact System Admin";

                    }

                }


            }
        }
     
    }
}