﻿using BusinessController;
using SeminarWebApplication.BusinessController;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SeminarWebApplication
{
    public partial class search_seminar : System.Web.UI.Page
    {
        commonController objCommonController = new commonController();

        public string htmldeleteHeaderCol = "";
        public string htmldeleteFooterCol = "";
        public int seminar_id
        {
            get
            {   /*Prevent cross-site scripting*/
                if (!string.IsNullOrEmpty(Request.QueryString["id"])) return Convert.ToInt32(Request.QueryString["id"]);
                else return 0;
            }
        } 
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["LoggedIn"] == null)
            {
                Session["LoggedIn"] = false;
                Response.Redirect("signin.aspx");

            }
            pageLevelAcess();
            if (!IsPostBack)
            {
                if (Convert.ToBoolean(Session["LoggedIn"].ToString()) == false)
                {
                    Response.Redirect("signin.aspx");
                }
                if (seminar_id != 0)
                {

                    deleteSeminar(seminar_id.ToString().Trim());

                }
                loadGrid();


            }

        }




        private void loadGrid()
        {
            SeminarController objController = new SeminarController();
            DataTable dt = new DataTable();
            objController.GetSeminarAll(ref dt);
            StringBuilder sb = new StringBuilder();

            if (dt != null)
                if (dt.Rows.Count > 0)
                    foreach (DataRow dr in dt.Rows)
                    {
                        string Title_Speaker="";
                        Title_Speaker ="<b>Title:</b> " + dr["seminar_title"].ToString().Trim();
                        Title_Speaker += "<br>" + "<b>Speaker:</b> " + dr["organizar_name"].ToString().Trim();  

                        string Time_Place="";
                        Time_Place = "<b>Time: </b>" + dr["Seminartime"].ToString().Trim();
                        Time_Place += "<br>" + "<b>Place:</b> " + dr["place"].ToString().Trim();

                        string date = "";
                        if(dr["seminar_date"].ToString().Trim ()!="")
                         date = Convert.ToDateTime(dr["seminar_date"].ToString()).ToShortDateString();
                        else
                         date = dr["seminar_date"].ToString();
                        sb.Append("<tr>");

                        sb.Append("<td>");
                        sb.Append(Title_Speaker);
                        sb.Append("</td>");

                        sb.Append("<td>");
                        sb.Append(Time_Place);
                        sb.Append("</td>");

                        sb.Append("<td>");
                        sb.Append(date);
                        sb.Append("</td>");

                        string activeDeactive = "";
                        string htmlActive = "<span class=\"label label-success\">Active</span>";
                        string htmlDeActive = "<span class=\"label label-info\">Deactive</span>";

                        if (dr["active"].ToString().Trim().ToLower() == "true")
                        {
                            activeDeactive = htmlActive;
                        }
                        else
                        {
                            activeDeactive = htmlDeActive;
                        }

                        sb.Append("<td>");
                        sb.Append((activeDeactive));
                        sb.Append("</td>");

                        string sendtopage = "seminar.aspx?id=" + dr["seminar_id"].ToString().Trim();
                        string lableName = "Edit";
                        string htmllink = "<a href=\"" + sendtopage + "\">" + lableName + "</a>";

                        sb.Append("<td>");
                        sb.Append((htmllink));
                        sb.Append("</td>");


                        htmldeleteHeaderCol = "<th tabindex=\"0\" rowspan=\"1\" colspan=\"1\">Delete</th>";
                        htmldeleteFooterCol = "<th rowspan=\"1\" colspan=\"1\">Delete</th>";
                        string lbldel = "";
                        string seminar_id = dr["seminar_id"].ToString().Trim();
                        sendtopage = "search-seminar.aspx?id=" + dr["seminar_id"].ToString().Trim();
                        lbldel = "Delete";
                        htmllink = "<a href=\"" + sendtopage + "\">" + lbldel + "</a>";
                        string strHmtlDe = htmllink;
                        sb.Append("<td>");
                        sb.Append((strHmtlDe));
                        sb.Append("</td>");

                        sb.Append("</tr>");

                    }

            ltData.Text = sb.ToString();



        }


        void pageLevelAcess()
        {
            string strcurrentPageName = Request.Url.AbsolutePath.ToString().Replace("/", "");
            /*Is Page is accessable for current user according to role*/
            if (objCommonController.SetRolesForPage(strcurrentPageName) == false)
            {
                Response.Redirect("default.aspx");
            }

        }

        void deleteSeminar(string seminar_id)
        {
             
            SeminarController objController = new SeminarController();
            /*Below code will Protect From SQL Injection in ASP.NET*/
            objController.DeleteSeminar(seminar_id);
            /*After Delete Redirect*/
            Response.Redirect("search-seminar.aspx");
        }


    }
}