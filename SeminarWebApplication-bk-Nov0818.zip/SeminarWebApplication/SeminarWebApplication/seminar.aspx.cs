﻿using BusinessController;
using SeminarWebApplication.BusinessController;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SeminarWebApplication
{
    public partial class seminar : System.Web.UI.Page
    {
        public string strDynamicMsg = "";
        commonController objCommonController = new commonController();

        public string requests_id
        {
            get
            {/*Prevent cross-site scripting*/
                if (!string.IsNullOrEmpty(Request.QueryString["requests_id"])) return Request.QueryString["requests_id"].ToString();
                else return "";
            }
        }

        void pageLevelAcess()
        {
            string strcurrentPageName = Request.Url.AbsolutePath.ToString().Replace("/", "");
            /*Is Page is accessable for current user according to role*/
            if (objCommonController.SetRolesForPage(strcurrentPageName) == false)
            {
                Response.Redirect("default.aspx");
            }

        }

        void clear()
        {
            
           

            cmbDept.SelectedIndex = -1;
            cmbTerm.SelectedIndex = -1;
            
            chkActive.Checked = true;

            Session["seminar_id"] = null;

        }
        void fillcmbData()
        {  
            
            DataTable tblDept = new DataTable();
            SeminarController objController = new SeminarController();
            objController.GetDeptAll(ref tblDept);


            cmbDept.DataSource = tblDept;
            cmbDept.DataTextField = "department_name";
            cmbDept.DataValueField = "department_id";
            cmbDept.DataBind();



            DataTable tblTerm = new DataTable();
            objController.GetTermAll(ref tblTerm);

            cmbTerm.DataSource = tblTerm;
            cmbTerm.DataTextField = "TermName";
            cmbTerm.DataValueField = "TermID";
            cmbTerm.DataBind();
            


        }
        protected void Page_Load(object sender, EventArgs e)
        {


            if (Session["LoggedIn"] == null)
            {
                Session["LoggedIn"] = false;
                Response.Redirect("signin.aspx");

            }
            pageLevelAcess();
            divmessage.Style["display"] = "none"; //hide            

            if (!IsPostBack)
            {
                if (Convert.ToBoolean(Session["LoggedIn"].ToString()) == false)
                {
                    Response.Redirect("signin.aspx");
                }

                fillcmbData();



                if (Request.QueryString["id"] != null)
                {
                    Session["seminar_id"] = Request.QueryString["id"].ToString().Trim();

                    fillDataForEdit(Session["seminar_id"].ToString());

                    if (Request.QueryString["requests_id"] != null)
                        strDynamicMsg = "Edit a record request";
                    else
                        strDynamicMsg = "Edit a record";

                }
                else
                {
                    strDynamicMsg = "Create a new record";
                }
            }

        }

        void fillDataForEdit(string UserID)
        {
             
            SeminarController objController = new SeminarController();
            DataTable tbl = new DataTable();
            objController.GetSeminarForEdit(ref tbl, UserID);

            DataRow[] drEdit = tbl.Select();
            if (drEdit.Length > 0)
            {
                
                
                
                txtSemTitle.Text = drEdit[0]["seminar_title"].ToString().Trim();
                txtOrganizar.Text = drEdit[0]["organizar_name"].ToString().Trim();

                txtPlace.Text = drEdit[0]["place"].ToString().Trim();
                txtTime.Text = drEdit[0]["Seminartime"].ToString().Trim();
                txtSemDate.Text = drEdit[0]["seminar_date"].ToString().Trim();
              


                cmbDept.SelectedValue = drEdit[0]["department_id"].ToString().Trim();
                cmbTerm.SelectedValue = drEdit[0]["TermID"].ToString().Trim();


                if (drEdit[0]["active"].ToString().Trim().ToLower() == "true")
                {
                    chkActive.Checked = true;
                }
                else
                {
                    chkActive.Checked = false;
                }



            }

        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            if (txtSemTitle.Text.Trim() == string.Empty)
                return;
            string department_id = cmbDept.SelectedValue.ToString();
            string TermID = cmbTerm.SelectedValue.ToString();
            bool active = false;


            active = chkActive.Checked;


            string seminar_id = "0";
            if (Session["seminar_id"] != null)
            {
                seminar_id = Session["seminar_id"].ToString();
            }
             
           
            SeminarController objController = new SeminarController();
            /*Below code will Protect From SQL Injection in ASP.NET*/
            objController.SaveSeminar(seminar_id,
                txtSemTitle.Text.Trim(),
                txtOrganizar.Text.Trim(),

                txtPlace.Text.Trim(),
                txtTime.Text.Trim(),
                txtSemDate.Text.Trim(),
                department_id,
                TermID,
                active



                );



            divmessage.Style["display"] = "block"; //visible
            clear();

            if (seminar_id != "0")
            {/*Redirect after update*/
                Response.Redirect("seminar.aspx");
                // Request.QueryString["id"] = null; 
            }

        }
    }
}