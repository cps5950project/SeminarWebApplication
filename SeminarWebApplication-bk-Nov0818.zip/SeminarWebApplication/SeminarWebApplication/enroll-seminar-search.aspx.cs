﻿using BusinessController;
using SeminarWebApplication.BusinessController;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SeminarWebApplication
{
    public partial class enroll_seminar_search : System.Web.UI.Page
    {
        commonController objCommonController = new commonController();

        public string htmldeleteHeaderCol = "";
        public string htmldeleteFooterCol = "";
        public int enroll_id
        {
            get
            {   /*Prevent cross-site scripting*/
                if (!string.IsNullOrEmpty(Request.QueryString["id"])) return Convert.ToInt32(Request.QueryString["id"]);
                else return 0;
            }
        } 
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["LoggedIn"] == null)
            {
                Session["LoggedIn"] = false;
                Response.Redirect("signin.aspx");

            }
            pageLevelAcess();
            if (!IsPostBack)
            {
                if (Convert.ToBoolean(Session["LoggedIn"].ToString()) == false)
                {
                    Response.Redirect("signin.aspx");
                }
                if (enroll_id != 0)
                {

                    CencelEnrollment(enroll_id.ToString().Trim());

                }
                ChckedChanged(null, null);
                loadGrid();


            }

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            //Session["RecordPageNum_AssetSearch"] = "1";
            //enroll_id = 0;
            //loadGrid();
            if(!chkShowAll.Checked)
            {
                loadGrid_BySearchCriteria();
            }
        }
        protected void ChckedChanged(object sender, EventArgs e)
        {
            
          if(chkShowAll.Checked)
          {
              lblTerm.Visible = false;
              lbldept.Visible = false;

              cmbDept.Visible=false;
              cmbTerm.Visible = false;
              btnSubmit.Visible = false;
              loadGrid();
          }
            else
          {
              lblTerm.Visible = true;
              lbldept.Visible = true;

              cmbDept.Visible = true;
              cmbTerm.Visible = true;
              btnSubmit.Visible = true;
              fillcmbData();
              loadGrid_BySearchCriteria();
          }
        }

        void fillcmbData()
        {

            DataTable tblDept = new DataTable();
            SeminarController objController = new SeminarController();
            objController.GetDeptAll(ref tblDept);


            cmbDept.DataSource = tblDept;
            cmbDept.DataTextField = "department_name";
            cmbDept.DataValueField = "department_id";
            cmbDept.DataBind();



            DataTable tblTerm = new DataTable();
            objController.GetTermAll(ref tblTerm);

            cmbTerm.DataSource = tblTerm;
            cmbTerm.DataTextField = "TermName";
            cmbTerm.DataValueField = "TermID";
            cmbTerm.DataBind();



        }
        private void loadGrid()
        {
            SeminarController objController = new SeminarController();
            DataTable dt = new DataTable();
            objController.GetSeminar_EnrollAll(ref dt,  Session["UserID"].ToString ()); 
            StringBuilder sb = new StringBuilder();

            if (dt != null)
                if (dt.Rows.Count > 0)
                    foreach (DataRow dr in dt.Rows)
                    {
                        string Title_Speaker = "";
                        Title_Speaker = "<b>Title:</b> " + dr["seminar_title"].ToString().Trim();
                        Title_Speaker += "<br>" + "<b>Speaker:</b> " + dr["organizar_name"].ToString().Trim();

                        string Time_Place = "";
                        Time_Place = "<b>Time: </b>" + dr["Seminartime"].ToString().Trim();
                        Time_Place += "<br>" + "<b>Place:</b> " + dr["place"].ToString().Trim();

                        string date = "";
                        if (dr["seminar_date"].ToString().Trim() != "")
                            date = Convert.ToDateTime(dr["seminar_date"].ToString()).ToShortDateString();
                        else
                            date = dr["seminar_date"].ToString();
                        sb.Append("<tr>");

                        sb.Append("<td>");
                        sb.Append(Title_Speaker);
                        sb.Append("</td>");

                        sb.Append("<td>");
                        sb.Append(Time_Place);
                        sb.Append("</td>");

                        sb.Append("<td>");
                        sb.Append(date);
                        sb.Append("</td>");

                        string activeDeactive = "";
                        //string htmlActive = "<span class=\"label label-success\">Active</span>";
                        //string htmlDeActive = "<span class=\"label label-info\">Deactive</span>";

                        //if (dr["active"].ToString().Trim().ToLower() == "true")
                        //{
                        //    activeDeactive = htmlActive;
                        //}
                        //else
                        //{
                        //    activeDeactive = htmlDeActive;
                        //}

                        string department_name = dr["department_name"].ToString();
                        string TermName = dr["TermName"].ToString();

                        string deptAndTerm="<b>Dept:</b> "+ department_name +"<br>  <b>Term: </b>" +TermName;
                        sb.Append("<td>");
                        sb.Append((deptAndTerm));
                        sb.Append("</td>");

                        string sendtopage = "enroll-seminar.aspx?id=" + dr["seminar_id"].ToString().Trim();
                        string lableName = "Enroll";
                        if (dr["EnrollStatus_enroll_id"].ToString().Trim() == "-1")
                        {
                            lableName = "Enroll";
                        }
                        else
                        {
                            lableName = "";//beacuse already enrolled..
                        }
                      
                        string htmllink = "<a href=\"" + sendtopage + "\">" + lableName + "</a>";

                        sb.Append("<td>");
                        sb.Append((htmllink));
                        sb.Append("</td>");


                        htmldeleteHeaderCol = "<th tabindex=\"0\" rowspan=\"1\" colspan=\"1\">Cencel</th>";
                        htmldeleteFooterCol = "<th rowspan=\"1\" colspan=\"1\">Cencel</th>";
                        string lbldel = "";
                        string EnrollStatus_enroll_id = dr["EnrollStatus_enroll_id"].ToString().Trim();
                        sendtopage = "enroll-seminar-search.aspx?id=" + dr["EnrollStatus_enroll_id"].ToString().Trim();

                        lbldel = "Cencel";

                        if (lableName=="")
                        {
                            lbldel = "Cencel"; //if alreay enrolled then cancel previous
                        }
                        else
                        {
                            lbldel = "";
                        }
                        htmllink = "<a href=\"" + sendtopage + "\">" + lbldel + "</a>";
                        string strHmtlDe = htmllink;
                        sb.Append("<td>");
                        sb.Append((strHmtlDe));
                        sb.Append("</td>");

                        sb.Append("</tr>");

                    }

            ltData.Text = sb.ToString();



        }



        private void loadGrid_BySearchCriteria() 
        {
            SeminarController objController = new SeminarController();
            DataTable dt = new DataTable();
            string department_id = cmbDept.SelectedValue.ToString();
            string TermID = cmbTerm.SelectedValue.ToString();


            objController.GetSeminar_EnrollByCriteria(ref dt, Session["UserID"].ToString(),TermID,department_id);
            StringBuilder sb = new StringBuilder();

            if (dt != null)
                if (dt.Rows.Count > 0)
                    foreach (DataRow dr in dt.Rows)
                    {
                        string Title_Speaker = "";
                        Title_Speaker = "<b>Title:</b> " + dr["seminar_title"].ToString().Trim();
                        Title_Speaker += "<br>" + "<b>Speaker:</b> " + dr["organizar_name"].ToString().Trim();

                        string Time_Place = "";
                        Time_Place = "<b>Time: </b>" + dr["Seminartime"].ToString().Trim();
                        Time_Place += "<br>" + "<b>Place:</b> " + dr["place"].ToString().Trim();

                        string date = "";
                        if (dr["seminar_date"].ToString().Trim() != "")
                            date = Convert.ToDateTime(dr["seminar_date"].ToString()).ToShortDateString();
                        else
                            date = dr["seminar_date"].ToString();
                        sb.Append("<tr>");

                        sb.Append("<td>");
                        sb.Append(Title_Speaker);
                        sb.Append("</td>");

                        sb.Append("<td>");
                        sb.Append(Time_Place);
                        sb.Append("</td>");

                        sb.Append("<td>");
                        sb.Append(date);
                        sb.Append("</td>");

                        string activeDeactive = "";
                        //string htmlActive = "<span class=\"label label-success\">Active</span>";
                        //string htmlDeActive = "<span class=\"label label-info\">Deactive</span>";

                        //if (dr["active"].ToString().Trim().ToLower() == "true")
                        //{
                        //    activeDeactive = htmlActive;
                        //}
                        //else
                        //{
                        //    activeDeactive = htmlDeActive;
                        //}

                        string department_name = dr["department_name"].ToString();
                        string TermName = dr["TermName"].ToString();

                        string deptAndTerm = "<b>Dept:</b> " + department_name + "<br>  <b>Term: </b>" + TermName;
                        sb.Append("<td>");
                        sb.Append((deptAndTerm));
                        sb.Append("</td>");

                        string sendtopage = "enroll-seminar.aspx?id=" + dr["seminar_id"].ToString().Trim();
                        string lableName = "Enroll";
                        if (dr["EnrollStatus_enroll_id"].ToString().Trim() == "-1")
                        {
                            lableName = "Enroll";
                        }
                        else
                        {
                            lableName = "";//beacuse already enrolled..
                        }

                        string htmllink = "<a href=\"" + sendtopage + "\">" + lableName + "</a>";

                        sb.Append("<td>");
                        sb.Append((htmllink));
                        sb.Append("</td>");


                        htmldeleteHeaderCol = "<th tabindex=\"0\" rowspan=\"1\" colspan=\"1\">Cencel</th>";
                        htmldeleteFooterCol = "<th rowspan=\"1\" colspan=\"1\">Cencel</th>";
                        string lbldel = "";
                        string EnrollStatus_enroll_id = dr["EnrollStatus_enroll_id"].ToString().Trim();
                        sendtopage = "enroll-seminar-search.aspx?id=" + dr["EnrollStatus_enroll_id"].ToString().Trim();

                        lbldel = "Cencel";

                        if (lableName == "")
                        {
                            lbldel = "Cencel"; //if alreay enrolled then cancel previous
                        }
                        else
                        {
                            lbldel = "";
                        }
                        htmllink = "<a href=\"" + sendtopage + "\">" + lbldel + "</a>";
                        string strHmtlDe = htmllink;
                        sb.Append("<td>");
                        sb.Append((strHmtlDe));
                        sb.Append("</td>");

                        sb.Append("</tr>");

                    }

            ltData.Text = sb.ToString();



        }

        void pageLevelAcess()
        {
            string strcurrentPageName = Request.Url.AbsolutePath.ToString().Replace("/", "");
            /*Is Page is accessable for current user according to role*/
            if (objCommonController.SetRolesForPage(strcurrentPageName) == false)
            {
                Response.Redirect("default.aspx");
            }

        }

        void CencelEnrollment(string enroll_id)
        {

            SeminarController objController = new SeminarController();
            /*Below code will Protect From SQL Injection in ASP.NET*/
            objController.CencelEnrollment(enroll_id);
            /*After Delete Redirect*/
            Response.Redirect("enroll-seminar-search.aspx");
        }


    }
}