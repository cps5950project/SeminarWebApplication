﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Collections;
using System.Data;
using System.Configuration;
using System.Data.SqlTypes;
using System.Data.OleDb;

namespace DbAccess
{
    public class Db
    {
        static SqlConnection objconn;
        public static SqlTransaction DbTran = null;
        static string strconn = ConfigurationManager.AppSettings["CsTr"].ToString();
        
        public static void creatconnection()
        {
            objconn = new SqlConnection(strconn);

            objconn.Open();
        }

        public static void ClosedbConnection()
        {
            objconn.Close();
            objconn.Dispose();
        }



        public static void selectDataReader(ref DataTable tbl, String query)
        {
            SqlCommand objcomm = new SqlCommand();
            creatconnection();
            objcomm.Connection = objconn;
            objcomm.CommandText = query;
            IDataReader objIDataReader = objcomm.ExecuteReader();
            DataSet ds = new DataSet();
            ds.Load(objIDataReader, LoadOption.PreserveChanges, "tbl");
            tbl = ds.Tables[0];
            ClosedbConnection();


        }
        public static void selectDataReader(ref DataTable tbl, string StoredProcedure, List<SqlParameter> Parameters)
        {
            SqlCommand objcomm = new SqlCommand();
            creatconnection();
            objcomm.Connection = objconn;
            objcomm.CommandText = StoredProcedure;
            objcomm.CommandType = CommandType.StoredProcedure;
            if (Parameters != null)
            {
                foreach (SqlParameter sParam in Parameters)
                {
                    /* Protect From SQL Injection in ASP.NET use SqlParameter*/
                    objcomm.Parameters.Add(sParam);

                }
            }

            IDataReader objIDataReader = objcomm.ExecuteReader();
            DataSet ds = new DataSet();
            ds.Load(objIDataReader, LoadOption.PreserveChanges, "tbl");
            tbl = ds.Tables[0];
            ClosedbConnection();


        }

        public static void selectDataReader(ref DataSet ds, string query)
        {
            SqlCommand objcomm = new SqlCommand();

            creatconnection();
            objcomm.Connection = objconn;
            objcomm.CommandText = query;
            IDataReader objIDataReader = objcomm.ExecuteReader();
            /*
             * --------------------------------------------------------
             * Need to make this code dynamic if require*/
            DataTable[] dt = new DataTable[2];
            DataTable tbl1 = new DataTable();
            DataTable tbl2 = new DataTable();
            dt[0] = tbl1;
            dt[1] = tbl2;
            ds.Tables.Add(tbl1);
            ds.Tables.Add(tbl2);
            /*----------------------------------------------------*/
            ds.Load(objIDataReader, LoadOption.PreserveChanges, dt);
            ClosedbConnection();

        }

        public static void selectDataReader(ref DataSet ds, string StoredProcedure, List<SqlParameter> Parameters)
        {


            SqlCommand objcomm = new SqlCommand();
            creatconnection();
            objcomm.Connection = objconn;
            objcomm.CommandText = StoredProcedure;
            objcomm.CommandType = CommandType.StoredProcedure;
            if (Parameters != null)
            {
                foreach (SqlParameter sParam in Parameters)
                {
                    /* Protect From SQL Injection in ASP.NET use SqlParameter*/
                    objcomm.Parameters.Add(sParam);

                }
            }
            IDataReader objIDataReader = objcomm.ExecuteReader();
            /*
             * --------------------------------------------------------
             * It is needed to make this code dynamic if required. */
            DataTable[] dt = new DataTable[2];
            DataTable tbl1 = new DataTable();
            DataTable tbl2 = new DataTable();
            dt[0] = tbl1;
            dt[1] = tbl2;
            ds.Tables.Add(tbl1);
            ds.Tables.Add(tbl2);
            /*----------------------------------------------------*/
            ds.Load(objIDataReader, LoadOption.PreserveChanges, dt);
            ClosedbConnection();

        }



        public static void BulkInsertion(OleDbDataReader dReader, string tablename)
        {
            try
            {
                SqlBulkCopy sqlBulk = new SqlBulkCopy(strconn);
                sqlBulk.BulkCopyTimeout = 0;
                sqlBulk.DestinationTableName = tablename;
                sqlBulk.WriteToServer(dReader);
                //ClosedbConnection();
                // return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void selectTable(DataTable tbl, string query)
        {
            SqlCommand objcomm = new SqlCommand();
            SqlDataAdapter objadapter = new SqlDataAdapter();

            creatconnection();
            objcomm.Connection = objconn;
            objcomm.CommandText = query;
            objadapter.SelectCommand = objcomm;
            objadapter.Fill(tbl);
            ClosedbConnection();

        }
        public static void updateTable(DataTable tbl, string query)
        {
            SqlCommand objcomm = new SqlCommand();
            SqlDataAdapter objadapter = new SqlDataAdapter();


            creatconnection();
            objcomm.Connection = objconn;
            objcomm.CommandText = query;
            objcomm.CommandType = CommandType.Text;
            objadapter.SelectCommand = objcomm;
            SqlCommandBuilder objcommandbuilder = new SqlCommandBuilder(objadapter);
            objcommandbuilder.ConflictOption = ConflictOption.OverwriteChanges;

            objadapter.DeleteCommand = objcommandbuilder.GetDeleteCommand();
            objadapter.UpdateCommand = objcommandbuilder.GetUpdateCommand();
            objadapter.InsertCommand = objcommandbuilder.GetInsertCommand();
            objadapter.Update(tbl);
            ClosedbConnection();


        }
        public static void executeQuery(string query)
        {
            SqlCommand objcomm = new SqlCommand();
            creatconnection();
            objcomm.Connection = objconn;
            objcomm.CommandText = query;
            objcomm.ExecuteNonQuery();
            ClosedbConnection();
        }

        public static void executeQuery(string StoredProcedureName, List<SqlParameter> Parameters)
        {
            SqlCommand objcomm = new SqlCommand();
            creatconnection();
            objcomm.Connection = objconn;
            objcomm.CommandText = StoredProcedureName;
            objcomm.CommandType = CommandType.StoredProcedure;
            if (Parameters != null)
            {
                foreach (SqlParameter sParam in Parameters)
                {
                    /* Protect From SQL Injection in ASP.NET use SqlParameter*/
                    objcomm.Parameters.Add(sParam);
                }
            }
            objcomm.ExecuteNonQuery();
            ClosedbConnection();
        }
        public static void runscript(String Query)
        {
            //Microsoft.SqlServer.Management.Smo.Server            server = null;
            //server = new Server(new ServerConnection(objconn));
            //server.ConnectionContext.ExecuteNonQuery(Query);
            
        }

        public static void ExecuteQueryForTransaction(string query)
        {
            try
            {
                beginTrans();
                SqlCommand objcomm = new SqlCommand();
                objcomm.Connection = objconn;
                objcomm.CommandText = query;
                objcomm.Transaction = DbTran;
                objcomm.ExecuteNonQuery();
                commitTrans();
                ClosedbConnection();
            }
            catch
            {

                rollbackTrans();
                throw;
            }
        }

        public static void BulkInsertTransaction(String queryToDelTempTable, OleDbDataReader dReader, string tablename, String queryToExeProcedure)
        {
            try
            {
                beginTrans();

                /*Delete Temp table*/
                SqlCommand objcomm = new SqlCommand();
                objcomm.Connection = objconn;
                objcomm.CommandText = queryToDelTempTable;
                objcomm.Transaction = DbTran;
                objcomm.ExecuteNonQuery();

                /*Import Excel Sheet in Temp Table*/
                SqlBulkCopy sqlBulk = new SqlBulkCopy(strconn);
                sqlBulk.BulkCopyTimeout = 0;
                sqlBulk.DestinationTableName = tablename;
                sqlBulk.WriteToServer(dReader);



                /*Insert data from temp table to original table*/
                objcomm.Connection = objconn;
                objcomm.CommandText = queryToExeProcedure;
                objcomm.Transaction = DbTran;
                objcomm.ExecuteNonQuery();

                commitTrans();
                ClosedbConnection();
            }
            catch
            {

                rollbackTrans();
                throw;
            }
        }

        public static void BulkInsertTransactionWithDataTable(String queryToDelTempTable, DataTable tbl, string tablename, String queryToExeProcedure)
        {
            try
            {
                beginTrans();

                /*Delete Temp table*/
                SqlCommand objcomm = new SqlCommand();
                objcomm.Connection = objconn;
                objcomm.CommandText = queryToDelTempTable;
                objcomm.Transaction = DbTran;
                objcomm.ExecuteNonQuery();

                /*Import Excel Sheet in Temp Table*/
                SqlBulkCopy sqlBulk = new SqlBulkCopy(strconn);
                sqlBulk.BulkCopyTimeout = 0;
                sqlBulk.DestinationTableName = tablename;
                sqlBulk.WriteToServer(tbl);



                /*Insert data from temp table to original table*/
                objcomm.Connection = objconn;
                objcomm.CommandText = queryToExeProcedure;
                objcomm.Transaction = DbTran;
                objcomm.ExecuteNonQuery();

                commitTrans();
                ClosedbConnection();
            }
            catch
            {

                rollbackTrans();
                throw;
            }
        }

        public static void BulkInsertTransaction_ForAsset(String queryToDelTempTable, OleDbDataReader dReader,
            string tablename, String queryToExeProcedure
            , String queryToExeProcedure_BulkUpdate)
        {
            try
            {
                beginTrans();

                /*Delete Temp table*/
                SqlCommand objcomm = new SqlCommand();
                objcomm.Connection = objconn;
                objcomm.CommandText = queryToDelTempTable;
                objcomm.Transaction = DbTran;
                objcomm.ExecuteNonQuery();

                /*Import Excel Sheet in Temp Table*/
                SqlBulkCopy sqlBulk = new SqlBulkCopy(strconn);
                sqlBulk.BulkCopyTimeout = 0;
                sqlBulk.DestinationTableName = tablename;
                sqlBulk.WriteToServer(dReader);

                /*Update orignal table with temp table if duplicate record on basis of tagnumber and serial_id 
                 * After update delete the record from temp table
                 * Deletetion is must in temp table becuase we want don't want to insert duplicate
                 */
                objcomm.Connection = objconn;
                objcomm.CommandText = queryToExeProcedure_BulkUpdate;
                objcomm.Transaction = DbTran;
                objcomm.ExecuteNonQuery();

                /*Insert data from temp table to original table*/
                objcomm.Connection = objconn;
                objcomm.CommandText = queryToExeProcedure;
                objcomm.Transaction = DbTran;
                objcomm.ExecuteNonQuery();

                commitTrans();
                ClosedbConnection();
            }
            catch
            {

                rollbackTrans();
                throw;
            }
        }
        public static void beginTrans()
        {
            //try
            //{
            if (DbTran == null)
            {
                if (objconn.State == 0)
                {
                    creatconnection();
                    DbTran = objconn.BeginTransaction();
                    // DbAdapter.SelectCommand.Transaction = DbTran;
                }
                else
                {
                    DbTran = objconn.BeginTransaction();
                    //DbAdapter.SelectCommand.Transaction = DbTran;
                }
            }

            //}
            //catch (Exception ex)
            //{
            //throw ex;
            //}

        }

        public static void commitTrans()
        {
            try
            {
                if (DbTran != null)
                {
                    DbTran.Commit();
                    DbTran = null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void rollbackTrans()
        {
            try
            {
                if (DbTran != null)
                {
                    DbTran.Rollback();
                    DbTran = null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}
